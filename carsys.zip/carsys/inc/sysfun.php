<?php
//页面跳转
function msgUrl($msg,$url){
	echo "<script>alert('$msg');location='$url'</script>";
	
}
	/*
	*  数值变带单位函数
	* $ascii 单位 亿,万,千,百,十
	*/
    function change_number($vaule,$unit='',$decimal=2){
		
		switch($unit){
			case '亿':
				return round($vaule/100000000,$decimal).'亿';
			break;
			case '万':
				return round($vaule/10000,$decimal).'万';
			break;
			case '千':
				return round($vaule/1000,$decimal).'千';
			break;
			case '百':
				return round($vaule/100,$decimal).'百';
			break;
			case '十':
				return round($vaule/10,$decimal).'十';
			break;
			default:
				return round($vaule,$decimal);
			break;
		}
		
	}
//图片上传
 function uploadImage($image){

 		  $filename = $_FILES[$image]['tmp_name'];
	      $file = $_FILES[$image]['name'];
	      $file_type = substr(strrchr($file, '.'), 1); //文件的后缀名 
	      $file_name = time().rand(1000,9999).'.'.$file_type;
		 // 为了保证文件夹里面的直接文件不要过多，所以，按日期生成文件夹存储文件
	      $path = '../upload/images/'.date("Ymd",time());
	      if(!file_exists($path)){
	          mkdir( $path,0777,true);

	      }
	      $destination = $path.'/'. $file_name  ;//路径加文件名称
	      move_uploaded_file($filename,$destination);
	      return 'upload/images/'.date("Ymd",time()).'/'. $file_name ;
	     

 }

 //返回json数据
function return_json_data($data){

	return json_encode($data);

}

 //生成和获取session 
 function session($session_name,$value=null){
 	if(!empty($value)){
 		$_SESSION[$session_name] = $value;
 	}else{
 		return empty($_SESSION[$session_name])?null:$_SESSION[$session_name];
 	}
 }


//获取IP地址
function getip() {
  static $ip = '';
  $ip = $_SERVER['REMOTE_ADDR'];
  if(isset($_SERVER['HTTP_CDN_SRC_IP'])) {
	 $ip = $_SERVER['HTTP_CDN_SRC_IP'];
	} elseif (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {
	$ip = $_SERVER['HTTP_CLIENT_IP'];

  } elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR']) AND preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {
	foreach ($matches[0] AS $xip) {
		if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {
		$ip = $xip;
		break;
		}
	}
}
	return $ip;
}


