<?php
//验证是否登录 - 超级管理员
function is_login_manage(){
	 $manage = session('manage_session');
	 if(empty($manage)){
	 	msgUrl('您没有登录',$url='login.php');die;
	 }

}
//验证是否登录 - 销售人员
function is_login_admin(){
	 $admin = session('admin_session');
	 if(empty($admin)){
	 	msgUrl('您没有登录',$url='login.php');die;
	 }

}
//统计记录总数
function get_rows($mysql,$table,$where=1){

	 $sql = "select count(*) as total from $table where $where ";
  	 $one = $mysql->doSqlOne($sql);
     return $count = $one['total'];

}


