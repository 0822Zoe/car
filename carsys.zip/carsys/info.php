<?php 
include_once('config/init.php'); //加载配置文件
$car_id = !empty($_GET['id'])?$_GET['id']:'0';
//查询需要修改的汽车信息
$car = $mysql->where("id='$car_id'")->find("tb_cars");
if(empty($car)){
 msgUrl('汽车信息不存在',$url='car_list.php');die();
}

//修改点击量
$mysql->where("id='$car_id'")->update("tb_cars",array('hits'=>$car['hits']+1));
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>首页</title>
		<!-- 引入bootsrap的基础样式文件 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入boosrapt的js基础库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
			.logo{ margin-top: -15px;;}
			
		</style>
	</head>
	<body>
		<div class="container">
			<!-- 导航栏开始 -->
		  <div class="row">
			<?php include_once('nav.php') ?>
		  </div>
		
		 <ol class="breadcrumb">
		  <li><a href="index.php">首页</a></li>
		  <li><a href="list.php">汽车管理</a></li>
		   <li class="active">汽车详情</li>
		 </ol>
		  <!-- 商家推荐开始 -->
		  <div class="row" style="margin-top: 10px;">
			 <div class="panel panel-default">
			   <div class="panel-body">
					 <div class="jumbotron">
					  <img src="<?php echo $car['car_image'] ?>" class="img-responsive img-rounded" />
					 </div>
					 <h1><?php echo $car['car_name'] ?></h1>
					 <h3>售价:￥<?php echo change_number($car['car_price'],$unit='万',$decimal=2); ?></h3>
					 <h3>库存(辆):<?php echo $car['sku'] ?></h3>
					 <h3>类型:<?php echo $car['car_category'] ?></h3>
					 <h3>品牌:<?php echo $car['car_brand'] ?></h3>
					 <h3>销量(辆):<?php echo $car['sales'] ?></h3>
					
					 <div class="jumbotron">
						<p><?php echo $car['car_desc'] ?></p>
					 </div>
				</div>
			 </div>
		</div>
		<!-- 商家推荐结束 -->
		
		
		  
		  <div class="row" style="margin-top:10px;">
			<?php include_once('footer.php') ?>
		  </div>
		  
		</div>
	</body>
</html>
