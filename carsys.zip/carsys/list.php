<?php 
include_once('config/init.php'); //加载配置文件
 //分类列表
   $keyword = !empty($_GET['keyword'])?$_GET['keyword']:'';
   $where = ' status=1  ';
   if(!empty($keyword)){
    $where .=" and (car_no ='$keyword' or car_name like '%$keyword%' or car_brand like '%$keyword%' or car_desc like '%$keyword%' )";
   }
  
   //参数处理 
  $page = empty($_GET['page'])?1:$_GET['page']; //如果地址栏没传递参数，则默认为第一页
  $page = (!is_numeric($page)||strpos($page,".")!==false)?1: $page; //如果地址栏传递的参数不是数字或者是小数，则为第一页
  $page = abs($page); //防止地址栏传输的
  //查询记录总数 
  $sql = "select count(*) as total from tb_cars where $where ";
  $one = $mysql->doSqlOne($sql);
  $count = $one['total']; //记录总数
  
  $page_size = empty($_GET['page_size'])?PAGE_SIZE:$_GET['page_size'];
  $pages = ceil($count/$page_size); //总共几页
  $page = ($page>$pages&&$pages!=0)?$pages:$page; //防止输入的当前页大于总页数
  
  $offset = ($page-1)*$page_size;
  
  $up_page = ($page-1)<1?1:($page-1); //上一页
  $next_page = ($page+1)>$pages?$pages:($page+1); //下一页
  //排序字段
  $fied_order = 'id';
  $fied_order = empty($_GET['fied_order'])?'id':$_GET['fied_order'];
  $type_order = empty($_GET['type_order'])?'desc':$_GET['type_order'];
  $type_order  = !in_array($type_order,array('desc','asc'))?'desc':$type_order;
  $type_order = $type_order=='desc'?'asc':'desc';
  $sql = "select * from tb_cars where $where order by  $fied_order  $type_order  limit $offset ,$page_size";
  $list = $mysql->doSql($sql);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>首页</title>
		<!-- 引入bootsrap的基础样式文件 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入boosrapt的js基础库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
			.logo{ margin-top: -15px;;}
			
		</style>
	</head>
	<body>
		<div class="container">
			<!-- 导航栏开始 -->
		  <div class="row">
			<?php include_once('nav.php') ?>
		</div>
		 <ol class="breadcrumb">
		   <li><a href="index.php">首页</a></li>
		   <li><a href="list.php">汽车管理</a></li>
		   <li class="active">汽车列表</li>
		 </ol>
		  <!-- 列表推荐开始 -->
		  <div class="row" style="margin-top: 10px;">
			 <div class="panel panel-default">
			   <div class="panel-heading">汽车列表</div>
			   <div class="panel-body">
					 <div class="row">
						 <div class="alert alert-info text-right" role="alert">
						<a href="list.php?keyword=<?php echo $keyword ?>&fied_order=car_price&type_order=<?php echo $type_order ?>" class="btn btn-danger btn-sm">价格</a>
						 <a href="list.php?keyword=<?php echo $keyword ?>&fied_order=sales&type_order=<?php echo $type_order ?>" class="btn btn-danger btn-sm">销量</a>
						 <a href="list.php?keyword=<?php echo $keyword ?>&fied_order=hits&type_order=<?php echo $type_order ?>" class="btn btn-danger btn-sm">人气</a>
						 </div>
						 
						 
						<?php foreach($list as $key=>$val){ ?>  
						<div class="media" style="margin-bottom: 5px; border: #ccc  dashed 1px ;">
						  <div class="media-left media-middle">
						    <a href="info.php?id=<?php echo $val['id'] ?>">
						      <img class="media-object  img-thumbnail" src="<?php echo $val['car_image'] ?>" alt="..." style="width: 150px;">
						    </a>
						  </div>
						  <div class="media-body">
							<ul class="list-group">
								<li class="list-group-item"> <h3 class="media-heading"><?php echo $val['car_name'] ?></h3></li>
							   <li class="list-group-item">
								   <span class="list-group-item-success">售价:￥<?php echo change_number($val['car_price'],$unit='万',$decimal=2); ?></span>
								   <span class="list-group-item-danger"> 库存(辆):<?php echo $val['sku'] ?></span>
								    <span class="list-group-item-success">销售(辆):<?php echo $val['sales'] ?></span>
								  
								   </li>
							   <li class="list-group-item">
								   <span class="list-group-item-success"> 品牌:<?php echo $val['car_brand'] ?></span>
								   <span class="list-group-item-danger">类型:<?php echo $val['car_category'] ?></span>
								  </li>
							    <li class="list-group-item"><a href="info.php?id=<?php echo $val['id'] ?>" class="btn btn-danger">详情</a></li>
							   
							 </ul>
						   
						   
						  </div>
						</div>
						 <?php } ?>
						
					</div>
			   </div>
			 </div>
		</div>
		<!-- 列表结束 -->
		<div class="row">
			<nav aria-label="Page navigation">
			  <ul class="pagination">
				<li><a style="border: 0px;">共<?php echo $count ?>条记录；一共<?php echo $pages ?>页,当前是<?php echo $page ?>页</a></li> 
				 <li><a href="list.php?page=1&keyword=<?php echo $keyword; ?>&fied_order=<?php echo $fied_order  ?>&type_order=<?php echo $type_order ?>">首页</a></li> 
			    <li>
			      <a href="list.php?page=<?php echo $up_page ?>&keyword=<?php echo $keyword; ?>&fied_order=<?php echo $fied_order  ?>&type_order=<?php echo $type_order ?>" aria-label="Previous">
			        <span aria-hidden="true">&laquo;上一页</span>
			      </a>
			    </li>
			  
			    <li>
			      <a href="list.php?page=<?php echo $next_page ?>&keyword=<?php echo $keyword; ?>&fied_order=<?php echo $fied_order  ?>&type_order=<?php echo $type_order ?>" aria-label="Next">
			        <span aria-hidden="true">&raquo;下一页</span>
			      </a>
			    </li>
				 <li><a href="list.php?page=<?php echo $pages ?>&keyword=<?php echo $keyword; ?>&fied_order=<?php echo $fied_order  ?>&type_order=<?php echo $type_order ?>">尾页</a></li> 
			  </ul>
			</nav>
		</div>
		
		  
		  <div class="row" style="margin-top:10px;">
			<?php include_once('footer.php') ?>
		  </div>
		  
		</div>
	</body>
</html>
