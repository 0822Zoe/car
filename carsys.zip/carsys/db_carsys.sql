-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2022-05-14 12:21:31
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_carsys`
--

-- --------------------------------------------------------

--
-- 表的结构 `tb_admin`
--

CREATE TABLE IF NOT EXISTS `tb_admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `real_name` varchar(255) DEFAULT NULL COMMENT '真实姓名',
  `admin_no` char(10) DEFAULT NULL COMMENT '员工编号',
  `admin_name` varchar(255) NOT NULL COMMENT '登录账号',
  `admin_password` varchar(255) NOT NULL COMMENT '登录密码',
  `phone` char(11) NOT NULL COMMENT '手机号码',
  `role` tinyint(1) NOT NULL DEFAULT '1' COMMENT '角色1销售2超级管理员',
  `add_time` datetime DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态1有效0失效',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `real_name`, `admin_no`, `admin_name`, `admin_password`, `phone`, `role`, `add_time`, `status`) VALUES
(1, '无名氏', '000000', 'admin', '123456', '13457996500', 2, '2022-05-04 21:05:04', 1),
(2, '姜蓝', '10002', 'blue', '123456', '13457996544', 1, '2022-05-08 22:56:02', 1),
(3, '赵菲', '10001', 'fly', '123456', '13457996511', 1, '2022-05-08 22:54:24', 1),
(4, '童路', '10000', 'road', '123456', '13457996599', 1, '2022-05-14 00:53:35', 1);

-- --------------------------------------------------------

--
-- 表的结构 `tb_cars`
--

CREATE TABLE IF NOT EXISTS `tb_cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `car_no` char(30) NOT NULL COMMENT '汽车编号',
  `car_name` varchar(255) NOT NULL COMMENT '汽车名称',
  `car_price` decimal(12,2) NOT NULL COMMENT '汽车价格',
  `car_desc` text COMMENT '汽车描述',
  `car_content` text COMMENT '汽车详情',
  `car_image` varchar(255) DEFAULT NULL COMMENT '汽车封面',
  `car_brand` varchar(255) DEFAULT NULL COMMENT '汽车品牌',
  `car_category` varchar(255) DEFAULT NULL COMMENT '汽车类型',
  `sku` int(10) NOT NULL DEFAULT '1000' COMMENT '库存',
  `sales` int(10) NOT NULL DEFAULT '0' COMMENT '销量',
  `hits` int(10) NOT NULL DEFAULT '0' COMMENT '点击量',
  `is_recommend` tinyint(255) NOT NULL DEFAULT '0' COMMENT '是否推荐1推荐0不推荐',
  `add_time` datetime DEFAULT NULL COMMENT '发布时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态1上架0下架',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `tb_cars`
--

INSERT INTO `tb_cars` (`id`, `car_no`, `car_name`, `car_price`, `car_desc`, `car_content`, `car_image`, `car_brand`, `car_category`, `sku`, `sales`, `hits`, `is_recommend`, `add_time`, `status`) VALUES
(1, 'C0001', '全新路虎·卫士90', '7000000.99', '全新路虎·卫士90 士·不可挡\r\n经典传承高辨识度车身造型\r\n强悍全地形能力与智能科技\r\n追求个性、崇尚自由之选\r\n', NULL, 'upload/images/20220508/16520143464820.JPG', '路虎', '汽/柴油型', 32, 4, 701, 1, '2022-05-04 16:40:37', 1),
(2, 'C0002', '大众 Polo', '110000.00', '外观简洁时尚，车身小巧，同时拥有主动刹车、驻车雷达、倒车影像等智能装备\r\n', NULL, 'upload/images/20220508/16520146751480.JPG', '大众', '汽/柴油型', 44, 34, 3600, 0, '2022-05-04 20:48:21', 1),
(3, 'C0003', '东风日产楼兰', '210000.00', '秋意九月，跟随楼兰穿越西北秘境天堂\r\n漫步起舞茶卡盐湖，天空之镜一望无际\r\n天上美玉落人间，是翡翠湖的曼妙绝色\r\n苍茫戈壁如丝带飞舞，直指苍穹天路\r\n魔幻莫测的水上雅丹，是博大、沧桑，亦是柔情\r\n', NULL, 'upload/images/20220508/16520211453208.JPG', '东风日产', '汽/柴油型', 26, 13, 901, 0, '2022-05-04 20:49:17', 1),
(5, '202205080926306456', '保时捷 911 Turbo S', '1270000.00', '与保时捷一起感受驾驭冰雪，破风前行的乐趣。游刃冰雪，玩得开心。\r\n', NULL, 'upload/images/20220508/16520138639160.JPG', '保时捷 ', '电动型', 2, 1, 403, 1, '2022-05-08 09:26:30', 1),
(6, '202205081155592305', '奥迪A6 Avant e-tron ', '410000.00', '独具未来型格，明日科技尽显高阶体验，奥迪A6 Avant e-tron concept带来空间与续航的双重灵感，一汽奥迪与你一起开拓未来新境！ \r\n', NULL, 'upload/images/20220508/16520121261178.jpg', '奥迪', '电动型', 8, 6, 225, 0, '2022-05-08 11:55:59', 1),
(7, '202205081206176874', '奥迪A7 Sportback', '580000.00', '传承经典造型，展现唯美气质\r\n奥迪A7 Sportback 以极致纯粹诠释感性美学 \r\n光影之外，纯粹之中\r\n', NULL, 'upload/images/20220508/16520115984011.JPG', '奥迪', '汽/柴油型', 6, 3, 238, 1, '2022-05-08 12:06:17', 1);

-- --------------------------------------------------------

--
-- 表的结构 `tb_order`
--

CREATE TABLE IF NOT EXISTS `tb_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `order_sn` char(60) DEFAULT NULL COMMENT '订单编号',
  `car_id` int(10) NOT NULL COMMENT '汽车id',
  `car_name` varchar(255) DEFAULT NULL COMMENT '汽车名称',
  `car_image` varchar(255) DEFAULT NULL COMMENT '汽车图片',
  `car_brand` varchar(255) DEFAULT NULL COMMENT '汽车品牌',
  `car_category` varchar(255) DEFAULT NULL COMMENT '汽车类型',
  `uid` int(10) NOT NULL COMMENT '客户id',
  `number` int(10) NOT NULL DEFAULT '1' COMMENT '购买数量',
  `buy_money` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `buy_time` datetime DEFAULT NULL COMMENT '购买时间',
  `pay_type` enum('分期','全款') NOT NULL DEFAULT '全款' COMMENT '支付方式',
  `pay_money` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '已支付多少钱',
  `status` tinyint(1) DEFAULT '10' COMMENT '状态10待提车 20已提车30 订单取消',
  `admin_id` int(10) NOT NULL DEFAULT '0' COMMENT '跟进销售员id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `tb_order`
--

INSERT INTO `tb_order` (`id`, `order_sn`, `car_id`, `car_name`, `car_image`, `car_brand`, `car_category`, `uid`, `number`, `buy_money`, `buy_time`, `pay_type`, `pay_money`, `status`, `admin_id`) VALUES
(9, 'FN202205082335288573', 6, '奥迪A6 Avant e-tron ', 'upload/images/20220508/16520121261178.jpg', '奥迪', '电动型', 4, 1, '410000.00', '2022-05-08 23:35:28', '全款', '50000.00', 10, 2),
(10, 'FN202205082347017989', 3, '东风日产楼兰', 'upload/images/20220508/16520211453208.JPG', '东风日产', '汽/柴油型', 4, 1, '210000.00', '2022-05-08 23:47:01', '全款', '30000.00', 10, 2),
(11, 'FN202205091324317184', 1, '全新路虎·卫士90', 'upload/images/20220508/16520143464820.JPG', '路虎', '汽/柴油型', 7, 1, '7000000.99', '2022-05-09 13:24:31', '全款', '40000.00', 10, 4),
(12, 'FN202205091410281240', 6, '奥迪A6 Avant e-tron ', 'upload/images/20220508/16520121261178.jpg', '奥迪', '电动型', 4, 1, '410000.00', '2022-05-09 14:10:28', '全款', '111111.00', 20, 2),
(13, 'FN202205091412511312', 6, '奥迪A6 Avant e-tron ', 'upload/images/20220508/16520121261178.jpg', '奥迪', '电动型', 4, 1, '410000.00', '2022-05-09 14:12:51', '分期', '10000.00', 20, 2),
(14, 'FN202205092244591245', 2, '大众 Polo', 'upload/images/20220508/16520146751480.JPG', '大众', '汽/柴油型', 8, 1, '110000.00', '2022-05-09 22:44:59', '全款', '110000.00', 20, 3);

-- --------------------------------------------------------

--
-- 表的结构 `tb_setting`
--

CREATE TABLE IF NOT EXISTS `tb_setting` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `logo` varchar(255) DEFAULT NULL COMMENT 'logo',
  `site_name` varchar(255) DEFAULT NULL COMMENT '系统名称',
  `banner1` varchar(255) DEFAULT NULL COMMENT '幻灯片1',
  `banner2` varchar(255) DEFAULT NULL COMMENT '幻灯片2',
  `banner3` varchar(255) DEFAULT NULL COMMENT '幻灯片3',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `tb_setting`
--

INSERT INTO `tb_setting` (`id`, `logo`, `site_name`, `banner1`, `banner2`, `banner3`) VALUES
(1, 'upload/images/20220508/16520246722479.JPG', '汽车销售管理系统', 'upload/images/20220508/16520103705524.JPG', 'upload/images/20220508/16520108714730.JPG', 'upload/images/20220508/16520108715272.JPG');

-- --------------------------------------------------------

--
-- 表的结构 `tb_user`
--

CREATE TABLE IF NOT EXISTS `tb_user` (
  `uid` int(10) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `username` varchar(255) DEFAULT NULL COMMENT '客户登录账号',
  `password` varchar(255) DEFAULT NULL COMMENT '客户登录密码',
  `real_name` varchar(255) DEFAULT NULL COMMENT '客户姓名',
  `sex` varchar(255) DEFAULT NULL COMMENT '客户性别',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `phone` char(11) NOT NULL COMMENT '手机号码',
  `address` varchar(255) DEFAULT NULL COMMENT '客户住址',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1有效 0失效',
  `admin_id` int(11) NOT NULL DEFAULT '0' COMMENT '跟进的销售员id',
  `reg_time` datetime DEFAULT NULL COMMENT '注册时间',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `tb_user`
--

INSERT INTO `tb_user` (`uid`, `username`, `password`, `real_name`, `sex`, `birthday`, `phone`, `address`, `status`, `admin_id`, `reg_time`) VALUES
(1, '20220507124978', '123456', '赵璐璐', '女', '2022-05-13', '15296485232', '广西省南宁市新河路55号', 1, 2, '2022-05-07 12:48:33'),
(2, 'zhao', '12345678', '何菲菲', '女', '2022-05-27', '15296485255', '北京天安路55号', 1, 3, '2022-05-07 13:18:28'),
(3, '20220508081152', 'Hu', '胡峰', '男', '2022-05-05', '13457996544', '北京朝阳区青秀路6号', 1, 2, '2022-05-08 08:29:22'),
(4, '20220508114475', 'LULU', '晓路', '女', '1982-06-16', '13457996599', '河北省石家庄市桥西区红旗大街333号', 1, 2, '2022-05-08 11:51:04'),
(5, '2022050945779', 'rob', '罗一铭', '男', '1985-10-16', '15687953346', '河南省郑州市金水区银基大厦A座706', 1, 2, '2022-05-09 10:32:25'),
(6, '2022050934776', 'Lisa', '黄嘉瑗', '女', '1995-10-09', '17800597631', '河北省石家庄市新华区新石路家属院', 1, 4, '2022-05-09 10:41:08'),
(7, '20220509229876', 'seven', '白淼', '女', '1992-07-10', '13377653402', '四川省成都市锦江区双桂路342号', 1, 4, '2022-05-09 10:47:21'),
(8, '20220509442398', 'cloud', '王云', '女', '1985-10-17', '17633452980', '四川省成都市金牛区抚琴西路171号', 1, 3, '2022-05-09 22:32:08');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
