<?php 
include_once('config/init.php'); //加载配置文件
$setting = $mysql->where("id='1'")->find("tb_setting");
?>
<nav class="navbar navbar-default">
			    <div class="container-fluid">
			      <!-- Brand and toggle get grouped for better mobile display -->
			      <div class="navbar-header">
			        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			          <span class="sr-only">Toggle navigation</span>
			          <span class="icon-bar"></span>
			          <span class="icon-bar"></span>
			          <span class="icon-bar"></span>
			        </button>
			        <a class="navbar-brand" href="#"><img src="<?php echo $setting['logo'] ?>"  class="pull-left img-circle logo" height="45"><span class="pull-left">汽车商城</span></a>
			      </div>
			  
			      <!-- Collect the nav links, forms, and other content for toggling -->
			      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			        <ul class="nav navbar-nav">
					   <li class="active"><a href="index.php">首页<span class="sr-only">(current)</span></a></li>
					   <li><a href="list.php">汽车列表</a></li>
					 </ul>
				     <form class="navbar-form navbar-right" action="list.php" method="get">
				             <div class="form-group">
				               <input type="text" class="form-control" name="keyword" placeholder="输入想要爱车">
				             </div>
				             <button type="submit" class="btn btn-success">搜索</button>
				    </form>
				   
				  <!-- /.navbar-collapse -->
			    </div><!-- /.container-fluid -->
</nav>
			