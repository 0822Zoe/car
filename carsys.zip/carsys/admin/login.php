<?php
  include_once('../config/init.php'); //加载配置文件
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>后台登录</title>
		<style type="text/css">
			*{ padding: 0; margin: 0;}
			html,body{ height: 100%;}
			body{ display: flex; justify-content: center; align-items: center; background-image: url(bootstrap/images/bg.png); background-size: 100%;}
			ul,li{ list-style: none;}
			.box{ width: 300px; margin: auto; border: #006400 solid 1px;;}
			.box h1{ text-align: center; font-size: 18px; font-weight: normal; background-color: darkgreen; color: floralwhite; padding: 10px;}
			.box li{ margin-bottom: 8px;;}
			.box form{ padding: 10px;;}
			.form-input{ border: #111 solid 1px; border-radius: 3px; height: 25px;;}
			.btn{ padding: 2px 10px;; margin-left: 20px;;}
			.success-btn{ height: 25px;  background-color: #006400; color: #fff; border: #006400  solid ;}
			.danger-btn{ height: 25px;  background-color: darkred; color: #fff; border: 1px solid darkred ;}
		</style>
	</head>
	<body>
		<div class="box">
			<h1>登陆后台</h1>
		<form method="post" action="login.php">
			<ul>
				<li><label>登录账号：</label><input type="text" name="username" class="form-input" /></li>
			
				<li><label>登录密码：</label><input type="password" name="password" class="form-input" /></li>
				
				<li><button type="submit" class="btn success-btn">登陆</button><button type="reset" class="btn danger-btn">重置</button></li>
			</ul>
			
		</form>
		</div>
	</body>
</html>
<?php
  $data = $_POST;
  if(!empty($data)){
	  $username = $data['username'];
	  $password = $data['password'];
	  //可以根据用用户编号、手机号码、登录账号三个进行登录
	  $admin = $mysql->where("admin_password='$password' and (admin_name='$username' or phone='$username' or admin_no='$username') and status='1' and role='1' ")->find("tb_admin");
	  if(!empty($admin)){
		  session('admin_session',$admin);//生成session
		  msgUrl('登录成功',$url='user_list.php');die();
	  }else{
		   msgUrl('账号密码错误，登录失败',$url='login.php');die();
	  }
	  
  }
 ?>
