<?php
 include_once('../config/init.php'); //加载配置文件
is_login_admin();//验证是否登录
//获取当前登陆的销售员信息
$admin_session = session('admin_session');
//根据车的id查询车的信息
$id = !empty($_GET['id'])?$_GET['id']:'0';
$car = $mysql->where("id='$id' and status=1 ")->find("tb_cars");


?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>下单页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>
				
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				  <li><a href="javascript:void(0)">首页</a></li>
				  <li><a href="javascript:void(0)">订单管理</a></li>
				  <li class="active">下单</li>
				</ol>
				
				<form method="post" action="order_add_step2.php" enctype="multipart/form-data">
				  <div class="form-group">
				    <label>客户手机号</label>
				    <input type="text" class="form-control" name="phone">
				  </div>
				  
				  <div class="form-group">
				    <label>汽车编号</label>
				    <input type="text" class="form-control" name="car_no" value="<?php echo empty($car['car_no'])?'':$car['car_no'] ?>">
				  </div>
				  
				  <button class="btn btn-success" type="submit">下一步</button>
				  <button class="btn btn-danger" type="reset">取消</button>
				</form>
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->
			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
		</div>
	</body>
</html>


 