<?php
   include_once('../config/init.php');
   is_login_admin();//验证是否登录
  
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>我的业绩</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<script src="bootstrap/js/echarts.min.js" ></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a {
		    color: #fff;
		}
		.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
		  
		    vertical-align: middle;
		  
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>	
					
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				 <li><a href="javascript:void(0)">首页</a></li>
				 <li><a href="javascript:void(0)">订单管理</a></li>
				 <li class="active">订单列表</li>
				</ol>
				<form class="form-inline" method="post" action="analysis_ajax.php" id="searchForm">
				  <div class="form-group">
					 <input type="date" class="form-control"placeholder="开始日期" name="begin_date">
				  </div>
				  <div class="form-group">
				  		<input type="date" class="form-control"placeholder="结束日期" name="end_date">
				  </div>
				 
				  <button type="submit" class="btn btn-success">查询</button>
				</form>
				<br>
				<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
				  <legend>统计分析图表</legend>
				</fieldset>
				 <!-- 为 ECharts 准备一个定义了宽高的 DOM -->
				  
				  <div id="main_line" style="width: 90%;height:600px;">
				  				  
				  </div>
				
				
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->

			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
		</div>
		
		
		
		
	</body>
</html>
<script type="text/javascript">
// 基于准备好的dom，初始化echarts实例
var chartDom = document.getElementById('main_line');
var myChart = echarts.init(chartDom);
var option;

option = {
  title: {
    text: '统计图表'
  },
  tooltip: {
    trigger: 'axis'
  },
  legend: {
    data: []
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true
  },
  toolbox: {
    feature: {
      saveAsImage: {}
    }
  },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: ['总订单数(笔)','总数量(辆)', '单价(元)', '实收款(元)', '销售总额(元)']
  },
  yAxis: {
    type: 'value'
  },
  series: [
  ]
};



</script>

<script>
$(document).ready(function(){
	submit_search(); //进入马上执行ajax
	$("#searchForm").submit(function(){
		submit_search();
		return false;
	});
});
function submit_search(){
	var url=$("#searchForm").attr("action");
	
	$.ajax({
		type:'post',
		url:url,
		data:$("#searchForm").serialize(),
		async:false,
		dataType:'json',
		success:function(res){
			if(res.code==200){
				
				option.legend.data = []; //清空汽车品牌数据
				option.series=[]; //清空销售数据
				
				var d = res.data;
				for(var i=0;i<d.length;i++){
					option.legend.data[i]=d[i].car_brand;
					option.series[i]={
						name: d[i].car_brand,
						type: 'line',
						stack: 'Total',
						data: [d[i].count_numbers, d[i].sum_number, d[i].buy_money, d[i].sum_pay_money, d[i].total_money]
					}
				}
				
				
			 option && myChart.setOption(option,true);
			
			}
		}
	});
	return false;
	
}
</script>
