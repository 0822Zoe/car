<?php
 include_once('../config/init.php'); //加载配置文件
is_login_admin();//验证是否登录
//获取当前登陆的销售员信息
$admin_session = session('admin_session');
//根据车的car_no查询车的信息
$car_id = !empty($_POST['car_id'])?$_POST['car_id']:'0'; //获取汽车编号
$car = $mysql->where("id='$car_id' and status=1 ")->find("tb_cars");
if(empty($car)){
	msgUrl('车信息不存在',$url='car_list.php');die();
}
if($car['sku']<$_POST['number']){
	msgUrl('库存不足',$url='car_list.php');die();
}
//根据用户uid查询客户的信息
$uid = !empty($_POST['uid'])?$_POST['uid']:'0'; //获取客户phone
$user = $mysql->where("uid='$uid' and status=1 ")->find("tb_user");
if(empty($user)){
	msgUrl('客户不存在',$url='car_list.php');die();
}
//判断当前用户是不是当前登录的销售员的客户
if($admin_session['id']!=$user['admin_id']){
	msgUrl('不属于你的客户，不允许下单',$url='car_list.php');die();
}

$insert_data = array(
	'car_id'=>$car['id'],
	'car_name'=>$car['car_name'],
	'car_image'=>$car['car_image'],
	'car_brand'=>$car['car_brand'],
	'car_category'=>$car['car_category'],
	'uid'=>$user['uid'],
	'admin_id'=>$admin_session['id'],
	'number'=>$_POST['number'],
	'pay_money'=>$_POST['pay_money'],
	'status'=>$_POST['status'],
	'buy_money'=>$car['car_price'],
	'pay_type'=>$_POST['pay_type'],
	'buy_time'=>date("Y-m-d H:i:s",time()),
	'order_sn'=>'FN'.date("YmdHis",time()).rand(1111,9999)
);
	$result = $mysql->insert('tb_order',$insert_data);
   if($result){
	   //汽车库存减少，销量+
	  $mysql->where('id='.$car_id)->update('tb_cars',array('sku'=>$car['sku']-$_POST['number'],'sales'=>$car['sales']+$_POST['number']));
	  msgUrl('下单成功',$url='order_list.php');die();
   }else{
      msgUrl('下单失败',$url='car_list.php');die();
   }

?>


