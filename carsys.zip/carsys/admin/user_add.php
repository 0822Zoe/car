<?php
 include_once('../config/init.php'); //加载配置文件
is_login_admin();//验证是否登录
//获取当前登陆的销售员信息
$admin_session = session('admin_session');
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>客户列表页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>
				
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				  <li><a href="javascript:void(0)">首页</a></li>
				  <li><a href="javascript:void(0)">客户管理</a></li>
				  <li class="active">添加客户</li>
				</ol>
				
				<form method="post" action="user_add.php" enctype="multipart/form-data">
				  <div class="form-group">
				    <label>用户编号</label>
				    <input type="text" class="form-control" name="username">
				  </div>
				  <div class="form-group">
				    <label>用户昵称</label>
				    <input type="text" class="form-control" name="password">
				  </div>
				  <div class="form-group">
				    <label>真实姓名</label>
				    <input type="text" class="form-control" name="real_name">
				  </div>
				  <div class="form-group">
				    <label>手机号码</label>
				    <input type="tel" class="form-control" name="phone">
				  </div>
				  <div class="form-group">
				    <label>出生日期</label>
				    <input type="date" class="form-control" name="birthday">
				  </div>
				 
				
				  <div class="form-group">
				    <label>性别</label>
					<br>
				   <label class="radio-inline">
				     <input type="radio" name="sex"  value="男" checked="checked"> 男
				   </label>
				   <label class="radio-inline">
				     <input type="radio" name="sex"  value="女" > 女
				   </label>
				  </div>
				  <div class="form-group">
				    <label>住址</label>
				    <textarea class="form-control" name="address"></textarea>
				  </div>
				  
				  <div class="form-group">
				    <label>状态</label>
				  					<br>
				   <label class="radio-inline">
				     <input type="radio" name="status"   value="1" checked="checked">有效
				   </label>
				   <label class="radio-inline">
				     <input type="radio" name="status"  value="0" > 失效
				   </label>
				  </div>
				  <button class="btn btn-success" type="submit">添加</button>
				  <button class="btn btn-danger" type="reset">取消</button>
				</form>
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->
			
			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
		</div>
	</body>
</html>

<?php 
//提交添加
  if(!empty($_POST)){
	//如果不填，则随机一个账号
	$username = empty($_POST['username'])?date('YmdH',time()).rand(1111,9999):$_POST['username'];
    $real_name = $_POST['real_name'];
    $phone = $_POST['phone'];
    $password = empty($_POST['password'])?'123456':$_POST['password'];
    $birthday = $_POST['birthday'];
	$address = $_POST['address'];
	$sex = $_POST['sex'];
    $reg_time = date("Y-m-d H:i:s",time());
    $status = $_POST['status'];
	$admin_id = $admin_session['id'];
	
	
	//查询登录账号是否已经存在
	$user = $mysql->where("username='$username'")->find("tb_user");
	if(!empty($user)){
		 msgUrl('登录账号已经存在',$url='user_add.php');die();
	}
	//查询手机号是否已经存在
	$user = $mysql->where("phone='$phone'")->find("tb_user");
	if(!empty($user)){
		 msgUrl('手机号已经存在',$url='user_add.php');die();
	}
	
	
	$insert_data =array(
      'username' =>$username ,
      'real_name'=>$real_name,
      'phone'=>$phone,
      'password'=>$password,
	  'sex'=>$sex,
      'birthday'=>$birthday,
      'reg_time'=>$reg_time,
	  'status'=>$status,
      'address'=>$address,
	  'admin_id'=>$admin_id
  );
   $result = $mysql->insert('tb_user',$insert_data);
   if($result){
		msgUrl('添加成功',$url='user_list.php');die();
   }else{
      msgUrl('添加失败',$url='user_add.php');die();
   }


  }

 ?>
