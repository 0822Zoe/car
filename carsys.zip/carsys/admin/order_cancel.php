<?php
 include_once('../config/init.php'); //加载配置文件
is_login_admin();//验证是否登录
//获取当前登陆的销售员信息
$admin_session = session('admin_session');
//根据订单id查询的信息
$order_id = !empty($_POST['order_id'])?$_POST['order_id']:'0';
$order = $mysql->where("id='$order_id'")->find("tb_order");
if(empty($order)){
	msgUrl('订单信息不存在',$url='order_list.php');die();
}

if($admin_session['id']!=$order['admin_id']){
	msgUrl('不属于你的客户，不允许取消单',$url='order_list.php');die();
}
if($order['status']==30){
	msgUrl('订单已经取消，不需要再次取消',$url='order_list.php');die();
}


$update_data = array(
	'status'=>30,
);
	$result = $mysql->where("id = '$order_id'")->update('tb_order',$update_data);
   if($result){
	  //取消订单，将车的库存和销量还原
	  $car_id = $order['car_id'];
	  $car = $mysql->where("id='$car_id'")->find("tb_cars");
	  if(!empty($car)){
		   $mysql->where('id='.$order['car_id'])->update('tb_cars',array('sku'=>$car['sku']-$order['number'],'sales'=>$car['sales']-$order['number']));
	  }
	 
	  msgUrl('取消订单成功',$url='order_list.php');die();
   }else{
      msgUrl('取消订单失败',$url='order_list.php');die();
   }

?>


