<?php
 include_once('../config/init.php'); //加载配置文件
is_login_manage();//验证是否登录
//获取当前登陆的销售员信息
$uid = !empty($_GET['uid'])?$_GET['uid']:'0';
//查询需要修改的客户信息
$user = $mysql->where("uid='$uid'")->find("tb_user");
if(empty($user)){
 msgUrl('客户信息不存在',$url='user_list.php');die();
}
//读取销售列表
$admin_list = [];
$sql = "select * from tb_admin where status=1 and role=1 ";
$admin_list = $mysql->doSql($sql);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>客户列表页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>
				
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				  <li><a href="javascript:void(0)">首页</a></li>
				  <li><a href="javascript:void(0)">客户管理</a></li>
				  <li class="active">编辑客户</li>
				</ol>
				
				<form method="post" action="user_edit.php?uid=<?php echo $uid ?>" enctype="multipart/form-data">
				  <div class="form-group">
				    <label>用户编号</label>
				    <input type="text" class="form-control" name="username" value="<?php echo $user['username'] ?>">
				  </div>
				  <div class="form-group">
				    <label>用户昵称</label>
				    <input type="text" class="form-control" name="password" value="<?php echo $user['password'] ?>">
				  </div>
				  <div class="form-group">
				    <label>真实姓名</label>
				    <input type="text" class="form-control" name="real_name" value="<?php echo $user['real_name'] ?>">
				  </div>
				  <div class="form-group">
				    <label>手机号码</label>
				    <input type="tel" class="form-control" name="phone" value="<?php echo $user['phone'] ?>">
				  </div>
				  <div class="form-group">
				    <label>出生日期</label>
				    <input type="date" class="form-control" name="birthday" value="<?php echo $user['birthday'] ?>">
				  </div>
				 
				
				  <div class="form-group">
				    <label>性别</label>
					<br>
				   <label class="radio-inline">
				     <input type="radio" name="sex"  value="男" <?php if($user['sex']=='男') echo 'checked="checked"' ?>> 男
				   </label>
				   <label class="radio-inline">
				     <input type="radio" name="sex"  value="女" <?php if($user['sex']=='女') echo 'checked="checked"' ?>> 女
				   </label>
				  </div>
				  <div class="form-group">
				    <label>住址</label>
				    <textarea class="form-control" name="address"><?php echo $user['address'] ?></textarea>
				  </div>
				  <div class="form-group">
				    <label>跟进销售</label>
					<select class="form-control" name="admin_id">
						<option value="0">选择销售员</option>
						<?php foreach($admin_list as $key=>$val){ ?>
						<option value="<?php echo $val['id'] ?>"<?php if($val['id']==$user['admin_id']) echo 'selected="selected"'; ?> ><?php echo $val['real_name'].'-'.$val['admin_no'] ?></option>
						<?php }?>
					</select>
				  </div>
				  
				  <div class="form-group">
				    <label>状态</label>
				  					<br>
				   <label class="radio-inline">
				     <input type="radio" name="status"   value="1" <?php if($user['status']=='1') echo 'checked="checked"' ?>>有效
				   </label>
				   <label class="radio-inline">
				     <input type="radio" name="status"  value="0" <?php if($user['status']=='0') echo 'checked="checked"' ?>> 失效
				   </label>
				  </div>
				  <button class="btn btn-success" type="submit">修改</button>
				  <button class="btn btn-danger" type="reset">取消</button>
				</form>
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->
			
			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
		</div>
	</body>
</html>

<?php 
//提交添加
  if(!empty($_POST)){
	//如果不填，则随机一个账号
	$username = empty($_POST['username'])?date('YmdH',time()).rand(1111,9999):$_POST['username'];
    $real_name = $_POST['real_name'];
    $phone = $_POST['phone'];
    $password = empty($_POST['password'])?'123456':$_POST['password'];
    $birthday = $_POST['birthday'];
	$address = $_POST['address'];
	$sex = $_POST['sex'];
    $reg_time = date("Y-m-d H:i:s",time());
    $status = $_POST['status'];
	$admin_id = $_POST['admin_id'];
	
	
	//查询登录账号是否已经存在
	$user = $mysql->where("username='$username' and uid!='$uid'")->find("tb_user");
	if(!empty($user)){
		 msgUrl('登录账号已经存在',$url='user_edit.php?uid='.$uid);die();
	}
	//查询手机号是否已经存在
	$user = $mysql->where("phone='$phone' and uid!='$uid' ")->find("tb_user");
	if(!empty($user)){
		 msgUrl('手机号已经存在',$url='user_edit.php?uid='.$uid);die();
	}
	$update_data =array(
      'username' =>$username ,
      'real_name'=>$real_name,
      'phone'=>$phone,
      'password'=>$password,
	  'sex'=>$sex,
      'birthday'=>$birthday,
      'status'=>$status,
      'address'=>$address,
	  'admin_id'=>$admin_id
  );
   $result =  $mysql->where("uid='$uid'")->update('tb_user',$update_data);
   if($result){
		msgUrl('修改成功',$url='user_edit.php?uid='.$uid);die();
   }else{
      msgUrl('修改失败',$url='user_edit.php?uid='.$uid);die();
   }


  }

 ?>
