<?php
   include_once('../config/init.php');
  
   //获取当前登陆的销售员信息
   $admin_session = session('admin_session');
   $admin_id = $admin_session['id'];
   $begin_date = !empty($_POST['begin_date'])?$_POST['begin_date']:'';
   $end_date = !empty($_POST['end_date'])?$_POST['end_date']:'';
   $where = " 1 ";
   
   if(!empty($begin_date)){
	$begin_time = $begin_date." 00:00:00";
    $where .=" and ( buy_time >= '$begin_time')";
   }
   if(!empty($end_date)){
   	$end_time = $end_date." 23:59:59";
    $where .=" and ( buy_time <= '$end_time')";
   }
//按品牌统计 
$sql = "select car_brand,buy_money, count(*) as count_numbers,sum(number) as sum_number,sum(pay_money) as sum_pay_money from tb_order as o left join tb_user as u on o.uid=u.uid left join tb_admin as a on o.admin_id=a.id where $where group by car_brand ";
  $list = $mysql->doSql($sql);
  $data = [];
  foreach($list as $key=>$val){
	  $val['total_money'] = $val['buy_money']*$val['sum_number'];
	  $data[] = $val;
  }
  
  //按销售员统计
  $sql = "select a.real_name,count(*) as count_numbers,sum(number) as sum_number,sum(pay_money) as sum_pay_money, sum(buy_money*number) as total_money from tb_order as o left join tb_user as u on o.uid=u.uid left join tb_admin as a on o.admin_id=a.id where $where group by o.admin_id ";
 $sale_list = $mysql->doSql($sql);
 //print_r($sale_list);
    

 echo  json_encode(array('code'=>200,'data'=>$data,'sale_data'=>$sale_list));
  
  

?>