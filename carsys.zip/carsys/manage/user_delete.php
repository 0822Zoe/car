
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>用户删除页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
		</style>
	</head>
	<body>
		
	</body>
</html>


<?php 
include_once('../config/init.php');
is_login_manage();//验证是否登录
$uid = !empty($_GET['uid'])?$_GET['uid']:'0';

$user = $mysql->where("uid='$uid'")->find("tb_user");

if(empty($user)){
	msgUrl('客户信息不存在',$url='user_list.php');die();
}
$result =$mysql->where("uid='$uid'")->delete("tb_user");
if($result){
	//一起删除用户的订单
	$mysql->where("uid='$uid'")->delete("tb_order");
	 msgUrl('删除成功',$url='user_list.php');die();
   }else{
      msgUrl('删除失败',$url='user_list.php.php');die();
}

?>