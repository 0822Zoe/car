<?php
 include_once('../config/init.php'); //加载配置文件
is_login_manage();//验证是否登录
//获取当前登陆的销售员信息
$admin_session = session('admin_session');
//根据订单id获取订单信息
$order_id = !empty($_GET['id'])?$_GET['id']:'0'; 
$order = $mysql->where("id='$order_id'")->find("tb_order");
if(empty($order)){
	msgUrl('订单信息不存在',$url='order_list.php');die();
}

//判断当前用户是不是当前登录的销售员的客户

//订单的客户信息
$uid = $order['uid'];
$user = $mysql->where("uid='$uid'")->find("tb_user");


?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>订单详情</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>
				
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				  <li><a href="javascript:void(0)">首页</a></li>
				  <li><a href="javascript:void(0)">订单管理</a></li>
				  <li class="active">订单信息</li>
				</ol>
				<div class="alert alert-danger" role="alert">订单信息</div>
				<form method="post" action="order_cancel.php" enctype="multipart/form-data">
				<input type="hidden" name="order_id" value="<?php echo $order['id'] ?>" />
				<div class="panel panel-default">
				  <div class="panel-heading">客户信息</div>
				  <div class="panel-body">
							<div class="form-group">
								<table class="table table-bordered">
									<tr>
										<td width="80"><label>登录账号:</label></td>
										<td><label><?php echo $user['username']; ?></label></td>
									</tr>
									<tr>
										<td ><label>姓名:</label></td>
										<td><label><?php echo $user['real_name']; ?></label></td>
									</tr>
									<tr>
										<td><label>性别:</label></td>
										<td><label><?php echo $user['sex']; ?></label></td>
									</tr>
									<tr>
										<td><label>手机号码:</label></td>
										<td><label><?php echo $user['phone']; ?></label></td>
									</tr>
									<tr>
										<td><label>地址:</label></td>
										<td><label><?php echo $user['address']; ?></label></td>
									</tr>
									
								</table>
							</div>
				  </div>
				</div>
				
				<div class="panel panel-default">
				  <div class="panel-heading">汽车信息</div>
				  <div class="panel-body">
							<div class="form-group">
								<table class="table table-bordered">
									
									<tr>
										<td ><label>名称:</label></td>
										<td><label><?php echo $order['car_name']; ?></label></td>
									</tr>
									<tr>
										<td><label>品牌:</label></td>
										<td><label><?php echo $order['car_brand']; ?></label></td>
									</tr>
									<tr>
										<td><label>类型:</label></td>
										<td><label><?php echo $order['car_category']; ?></label></td>
									</tr>
									<tr>
										<td><label>图片:</label></td>
										<td><label><img src="../<?php echo $order['car_image']; ?>" class="img-thumbnail img-responsive" style="height: 200px;"></label></td>
									</tr>
									
									<tr>
										<td><label>价格:</label></td>
										<td><label><?php echo $order['buy_money']; ?></label></td>
									</tr>
									
								</table>
							</div>
				  </div>
				</div>
				
				<div class="panel panel-default">
				  <div class="panel-heading">订单信息</div>
				  <div class="panel-body">
							<div class="form-group">
								<table class="table table-bordered">
									<tr>
										<td width="80"><label>购买数量:</label></td>
										<td><label><?php echo $order['number']; ?></label></td>
									</tr>
									<tr>
										<td ><label>付款方式:</label></td>
										<td><label><?php echo $order['pay_type']; ?></label></td>
									</tr>
									<tr>
										<td><label>现在付款:</label></td>
										<td><label><?php echo $order['pay_money']; ?></label></td>
									</tr>
									<tr>
										<td ><label>订单状态:</label></td>
										<td>
											<?php if($order['status']==10){ ?>
												<label>预定</label>
											<?php }else if($order['status']==20){ ?>
												<label>已提车</label>
											<?php }else if($order['status']==30){ ?>
												<label>已取消</label>
											<?php } ?>
											
										</td>
									</tr>
									<tr>
										<td><label>下单时间:</label></td>
										<td><label><?php echo $order['buy_time']; ?></label></td>
									</tr>
									
								</table>
							</div>
				  </div>
				</div>
				<button class="btn btn-success" type="submit">取消订单</button>
				  
				</form>
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->
			
			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
		</div>
	</body>
</html>

