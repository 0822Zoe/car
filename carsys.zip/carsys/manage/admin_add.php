<?php
include_once('../config/init.php'); //加载配置文件
is_login_manage();//验证是否登录
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>销售员列表页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>
				
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				  <li><a href="javascript:void(0)">首页</a></li>
				  <li><a href="javascript:void(0)">销售员管理</a></li>
				  <li class="active">添加销售员</li>
				</ol>
				
				<form method="post" action="admin_add.php" enctype="multipart/form-data">
				  <div class="form-group">
				    <label>员工编号</label>
				    <input type="text" class="form-control" name="admin_no">
				  </div>
				  <div class="form-group">
				    <label>真实姓名</label>
				    <input type="text" class="form-control" name="real_name">
				  </div>
				  <div class="form-group">
				    <label>登录账号</label>
				    <input type="text" class="form-control" name="admin_name">
				  </div>
				  <div class="form-group">
				    <label>登录密码</label>
				    <input type="text" class="form-control" name="admin_password">
				  </div>
				  <div class="form-group">
				    <label>手机号码</label>
				    <input type="number" class="form-control" name="phone">
				  </div>
				 
				
				  <div class="form-group">
				    <label>状态</label>
					<br>
				   <label class="radio-inline">
				     <input type="radio" name="status" id="status1" value="0"> 失效
				   </label>
				   <label class="radio-inline">
				     <input type="radio" name="status" id="status2" value="1" checked="checked"> 有效
				   </label>
				  </div>
				  <button class="btn btn-success" type="submit">添加</button>
				  <button class="btn btn-danger" type="reset">取消</button>
				</form>
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->
			
			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
	
		</div>
	</body>
</html>

<?php 
//提交添加
  if(!empty($_POST)){
	$admin_name = $_POST['admin_name'];
    $real_name = $_POST['real_name'];
    $phone = $_POST['phone'];
    $admin_password = $_POST['admin_password'];
    $admin_no = $_POST['admin_no'];
	$role = 1;
    $add_time = date("Y-m-d H:i:s",time());
    $status = $_POST['status'];
	
	//查询员工编号是否已经存在
	$admin = $mysql->where("admin_no='$admin_no'")->find("tb_admin");
	if(!empty($admin)){
		 msgUrl('员工编号已经存在',$url='admin_add.php');die();
	}
	
	//查询员工登录账号是否已经存在
	$admin = $mysql->where("admin_name='$admin_name'")->find("tb_admin");
	if(!empty($admin)){
		 msgUrl('登录账号已经存在',$url='admin_add.php');die();
	}
	//查询员工手机号是否已经存在
	$admin = $mysql->where("phone='$phone'")->find("tb_admin");
	if(!empty($admin)){
		 msgUrl('手机号已经存在',$url='admin_add.php');die();
	}
	
	
	$insert_data =array(
      'admin_name' =>$admin_name ,
      'real_name'=>$real_name,
      'phone'=>$phone,
      'admin_password'=>$admin_password,
	  'admin_no'=>$admin_no,
      'role'=>$role,
      'add_time'=>$add_time,
	  'status'=>$status,
      'add_time'=>$add_time
  );
   $result = $mysql->insert('tb_admin',$insert_data);
   if($result){
		msgUrl('添加成功',$url='admin_list.php');die();
   }else{
      msgUrl('添加失败',$url='admin_add.php');die();
   }


  }

 ?>
