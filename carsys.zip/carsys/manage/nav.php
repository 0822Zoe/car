<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
</style>
<?php 
include_once('../config/init.php'); //加载配置文件
$setting = $mysql->where("id='1'")->find("tb_setting");
 //获取当前登录的用户的信息
$manage_s = session('manage_session');
$id =$manage_s['id']; 
$real_name =$manage_s['real_name']; 
$admin_name =$manage_s['admin_name'];
?>
<nav class="navbar navbar-default">
			  <div class="container-fluid">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>
			      <a class="navbar-brand" href="#"><img src="../<?php echo $setting['logo'] ?>" height="48" class="pull-left img-circle" style="margin-top: -15px;;"><span class=" pull-left"><?php echo $setting['site_name'] ?></span></a>
			    </div>
			
			    <!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			     
			     
			      <ul class="nav navbar-nav navbar-right">
			        <li><a href="#"><span class="glyphicon glyphicon-user"></span><?php echo $admin_name.'-'.$real_name; ?></a></li>
			        <li class="dropdown">
			          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">个人中心 <span class="caret"></span></a>
			          <ul class="dropdown-menu">
			            <li><a href="update_password.php">修改密码</a></li>
			            <li><a href="logout.php">安全退出</a></li>
			           
			          </ul>
			        </li>
			      </ul>
			    </div><!-- /.navbar-collapse -->
			  </div><!-- /.container-fluid -->
			</nav>