<?php
   include_once('../config/init.php');
   is_login_manage();//验证是否登录
  
  
   $keyword = !empty($_GET['keyword'])?$_GET['keyword']:'';
   $begin_date = !empty($_GET['begin_date'])?$_GET['begin_date']:'';
   $end_date = !empty($_GET['end_date'])?$_GET['end_date']:'';
   
   $where = " 1 ";
   if(!empty($keyword)){
    $where .=" and (order_sn like '%$keyword%'  )";
   }
   if(!empty($begin_date)){
   	$begin_time = $begin_date." 00:00:00";
    $where .=" and ( buy_time >= '$begin_time')";
   }
   if(!empty($end_date)){
   	$end_time = $end_date." 23:59:59";
    $where .=" and ( buy_time <= '$end_time')";
   }
  
   //参数处理 
  $page = empty($_GET['page'])?1:$_GET['page']; //如果地址栏没传递参数，则默认为第一页
  $page = (!is_numeric($page)||strpos($page,".")!==false)?1: $page; //如果地址栏传递的参数不是数字或者是小数，则为第一页
  $page = abs($page); //防止地址栏传输的
  //查询记录总数 
  $sql = "select count(o.id) as total from tb_order as o left join tb_user as u on o.uid=u.uid left join tb_admin as a on o.admin_id=a.id  where $where ";
  $one = $mysql->doSqlOne($sql);
  $count = $one['total']; //记录总数
  
  $page_size = empty($_GET['page_size'])?PAGE_SIZE:$_GET['page_size'];
  $pages = ceil($count/$page_size); //总共几页
  $page = ($page>$pages&&$pages!=0)?$pages:$page; //防止输入的当前页大于总页数
  
  $offset = ($page-1)*$page_size;
  
  $up_page = ($page-1)<1?1:($page-1); //上一页
  $next_page = ($page+1)>$pages?$pages:($page+1); //下一页
  //排序字段
  $fied_order = 'o.id';
  $type_order = empty($_GET['type_order'])?'desc':$_GET['type_order'];
  $type_order  = !in_array($type_order,array('desc','asc'))?'desc':$type_order;
  $sql = "select o.*,a.admin_name,a.real_name as sale_name,u.real_name,u.address,u.sex,u.phone from tb_order as o left join tb_user as u on o.uid=u.uid left join tb_admin as a on o.admin_id=a.id where $where order by  $fied_order  $type_order  limit $offset ,$page_size";
  $list = $mysql->doSql($sql);
  

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>订单列表页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a {
		    color: #fff;
		}
		.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
		  
		    vertical-align: middle;
		  
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>	
					
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				 <li><a href="javascript:void(0)">首页</a></li>
				 <li><a href="javascript:void(0)">订单管理</a></li>
				 <li class="active">订单列表</li>
				</ol>
				<form class="form-inline" method="get" action="order_list.php">
					<div class="form-group">
						 <input type="date" class="form-control"placeholder="开始日期" name="begin_date">
					</div>
					<div class="form-group">
						<input type="date" class="form-control"placeholder="结束日期" name="end_date">
					</div>
									 
				  <div class="form-group">
					 
				    <input type="text" class="form-control"placeholder="输入搜索关键字" name="keyword">
				  </div>
				 
				  <button type="submit" class="btn btn-success">查询</button>
				</form>
				<br>
				<table class="table table-hover">
					<tr>
						<td>ID</td>
						<td width="200">订单编号</td>
						<td width="120">汽车详情</td>
						<td>客户详情</td>
						<td>已付款</td>
						<td>付款方式</td>
						<td>数量</td>
						<td>单价</td>
						<td>状态</td>
						<td>跟进销售</td>
						<td width="90">下单时间</td>
						<td>操作</td>
						
					</tr>
					<?php if(empty($list)) echo "<tr><td colspan='13'>暂时信息</td></tr>"; ?>
					
					<?php foreach($list as $key=>$val){ ?>
					<tr>
						<td ><?php echo $val['id'] ?></td>
						<td><?php echo $val['order_sn'] ?></td>
						<td>
							<img src="../<?php echo $val['car_image']; ?>" class="img-thumbnail" style="height: 80px;">
							<?php echo $val['car_name']; ?><br>
							<?php echo $val['car_brand']; ?><br>
							<?php echo $val['car_category']; ?><br>
								
							
							
							</td>
						<td>
							<?php echo $val['real_name']; ?><br>
							<?php echo $val['sex']; ?><br>
							<?php echo $val['address']; ?><br>
							<?php echo $val['phone']; ?>
						</td>
						
						<td><?php echo change_number($val['pay_money'],$unit='万',$decimal=2); ?></td>
						<td><?php echo $val['pay_type']; ?></td>
						
						<td><?php echo $val['number'] ?></td>
						
						<td><?php echo change_number($val['buy_money'],$unit='万',$decimal=2); ?></td>
						<td>
							<?php if($val['status']==10){ ?>
								<span class="label label-danger">待提车</span>
							<?php }else if($val['status']==20){ ?>
								<span class="label label-success">已提车</span>
							<?php }else if($val['status']==30){ ?>
								<span class="label label-warning">已取消</span>
							<?php } ?>
							</td>
						<td><?php echo $val['sale_name']; ?></td>
						<td><?php echo $val['buy_time'] ?></td>
						<td><a href="order_info.php?id=<?php echo $val['id'] ?>"  class="btn btn-warning btn-sm">订单详情</a>
						<a href="order_delete.php?id=<?php echo $val['id'] ?>"  class="btn btn-danger btn-sm">删除订单</a>
						</td>
						
					</tr>
					<?php } ?>
					
				</table>
				
				<nav aria-label="Page navigation">
				  <ul class="pagination">
					<li><a style="border: 0px;">共<?php echo $count ?>条记录；一共<?php echo $pages ?>页,当前是<?php echo $page ?>页</a></li> 
					 <li><a href="order_list.php?page=1&keyword=<?php echo $keyword; ?>">首页</a></li> 
				    <li>
				      <a href="order_list.php?page=<?php echo $up_page ?>&keyword=<?php echo $keyword; ?>" aria-label="Previous">
				        <span aria-hidden="true">&laquo;上一页</span>
				      </a>
				    </li>
				  
				    <li>
				      <a href="order_list.php?page=<?php echo $next_page ?>&keyword=<?php echo $keyword; ?>" aria-label="Next">
				        <span aria-hidden="true">&raquo;下一页</span>
				      </a>
				    </li>
					 <li><a href="order_list.php?page=<?php echo $pages ?>&keyword=<?php echo $keyword; ?>">尾页</a></li> 
				  </ul>
				</nav>
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->

			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
		</div>
		
		
		
		
	</body>
</html>
