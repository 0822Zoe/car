<?php
 include_once('../config/init.php'); //加载配置文件
is_login_manage();//验证是否登录
$setting = $mysql->where("id='1'")->find("tb_setting");
if(empty($setting)){
 msgUrl('信息不存在',$url='car_list.php');die();
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>设置页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>
				
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				  <li><a href="javascript:void(0)">首页</a></li>
				  <li><a href="javascript:void(0)">设置管理</a></li>
				  <li class="active">设置</li>
				</ol>
				
				<form method="post" action="setting.php" enctype="multipart/form-data">
				  <div class="form-group">
				    <label>网站系统名称</label>
				    <input type="text" class="form-control" name="site_name" value="<?php echo $setting['site_name'] ?>">
				  </div>
				  <div class="form-group">
				      <label>网站logo</label>
				      <input type="file" class="form-control" name="logo" id="logo" style="width: 250px;">
				  <br>
				  <?php if(empty($setting['logo'])){ ?>
				  <img src="./bootstrap/images/default.jpg" style="height: 100px ;" id="show_logo" class="img-thumbnail" />
				  <?php }else{ ?>
				  <img src="../<?php echo $setting['logo'] ?>" style="height: 100px ;" id="show_logo" class="img-thumbnail" />
				  <?php } ?>
				    </div>
				  
				  <div class="form-group">
				    <label>幻灯片1</label>
				    <input type="file" class="form-control" name="banner1" id="banner1" style="width: 250px;">
				<br>
				<?php if(empty($setting['banner1'])){ ?>
				<img src="./bootstrap/images/default.jpg" style="height: 100px ;" id="show_banner1" class="img-thumbnail" />
				<?php }else{ ?>
				<img src="../<?php echo $setting['banner1'] ?>" style="height: 100px ;" id="show_banner1" class="img-thumbnail" />
				<?php } ?>
				  </div>
				  <div class="form-group">
				      <label>幻灯片2</label>
				      <input type="file" class="form-control" name="banner2" id="banner2" style="width: 250px;">
				  <br>
				  <?php if(empty($setting['banner2'])){ ?>
				  <img src="./bootstrap/images/default.jpg" style="height: 100px ;" id="show_banner2" class="img-thumbnail" />
				  <?php }else{ ?>
				  <img src="../<?php echo $setting['banner2'] ?>" style="height: 100px ;" id="show_banner2" class="img-thumbnail" />
				  <?php } ?>
				    </div>
				   
				   <div class="form-group">
				       <label>幻灯片3</label>
				       <input type="file" class="form-control" name="banner3" id="banner3" style="width: 250px;">
				   <br>
				   <?php if(empty($setting['banner2'])){ ?>
				   <img src="./bootstrap/images/default.jpg" style="height: 100px ;" id="show_banner3" class="img-thumbnail" />
				   <?php }else{ ?>
				   <img src="../<?php echo $setting['banner3'] ?>" style="height: 100px ;" id="show_banner3" class="img-thumbnail" />
				   <?php } ?>
				     </div>
				    
				 
				  <button class="btn btn-success" type="submit">确定</button>
				  <button class="btn btn-danger" type="reset">取消</button>
				</form>
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->
			
			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
		</div>
	</body>
</html>
<script>
  const ipt1 = document.querySelector('#banner1')
  const img1 = document.querySelector('#show_banner1')
  ipt1.addEventListener('change', (event) => {
  	// 获取当前图片信息
    let file = event.target.files[0]
    const reader = new FileReader()
    // 转化使用bese64格式
    reader.readAsDataURL(file)
    // 成功后的回调
    reader.onload = function () {
      img1.setAttribute('src',this.result)
    }
  })
  
  const ipt2 = document.querySelector('#banner2')
  const img2 = document.querySelector('#show_banner2')
  ipt2.addEventListener('change', (event) => {
  	// 获取当前图片信息
    let file = event.target.files[0]
    const reader = new FileReader()
    // 转化使用bese64格式
    reader.readAsDataURL(file)
    // 成功后的回调
    reader.onload = function () {
      img2.setAttribute('src',this.result)
    }
  })
  
  const ipt3 = document.querySelector('#banner3')
  const img3 = document.querySelector('#show_banner3')
  ipt3.addEventListener('change', (event) => {
  	// 获取当前图片信息
    let file = event.target.files[0]
    const reader = new FileReader()
    // 转化使用bese64格式
    reader.readAsDataURL(file)
    // 成功后的回调
    reader.onload = function () {
      img3.setAttribute('src',this.result)
    }
  })
  
  const iptlogo = document.querySelector('#logo')
  const logo = document.querySelector('#show_logo')
  iptlogo.addEventListener('change', (event) => {
  	// 获取当前图片信息
    let file = event.target.files[0]
    const reader = new FileReader()
    // 转化使用bese64格式
    reader.readAsDataURL(file)
    // 成功后的回调
    reader.onload = function () {
      logo.setAttribute('src',this.result)
    }
  })
  
</script>

<?php 
//提交添加
  if(!empty($_POST)){
	$site_name = $_POST['site_name'];
   
	
	$update_data =array(
      'site_name' =>$site_name ,
  );
  //上传图片
  if(!empty($_FILES['logo']['tmp_name'])){
  	$logo = uploadImage('logo');
  	$update_data['logo'] = $logo;
  }
  //上传图片
  if(!empty($_FILES['banner1']['tmp_name'])){
  	$banner1 = uploadImage('banner1');
  	$update_data['banner1'] = $banner1;
  }
  //上传图片
  if(!empty($_FILES['banner2']['tmp_name'])){
  	$banner2 = uploadImage('banner2');
  	$update_data['banner2'] = $banner2;
  }
  //上传图片
  if(!empty($_FILES['banner3']['tmp_name'])){
  	$banner3 = uploadImage('banner3');
	$update_data['banner3'] = $banner3;
  }
   $result =  $mysql->where("id='1'")->update('tb_setting',$update_data);
   if($result){
		msgUrl('编辑成功',$url='setting.php');die();
   }else{
      msgUrl('编辑失败',$url='setting.php');die();
   }


  }

 ?>
