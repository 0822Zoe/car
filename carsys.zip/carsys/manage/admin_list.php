<?php
   include_once('../config/init.php');
   is_login_manage();//验证是否登录
   //分类列表
   $keyword = !empty($_GET['keyword'])?$_GET['keyword']:'';
   $where = ' role=1  ';
   if(!empty($keyword)){
    $where .=" and (phone like '%$keyword%' or admin_name like '%$keyword%' or real_name like '%$keyword%' )";
   }
  
   //参数处理 
  $page = empty($_GET['page'])?1:$_GET['page']; //如果地址栏没传递参数，则默认为第一页
  $page = (!is_numeric($page)||strpos($page,".")!==false)?1: $page; //如果地址栏传递的参数不是数字或者是小数，则为第一页
  $page = abs($page); //防止地址栏传输的
  //查询记录总数 
  $sql = "select count(*) as total from tb_admin where $where ";
  $one = $mysql->doSqlOne($sql);
  $count = $one['total']; //记录总数
  
  $page_size = empty($_GET['page_size'])?PAGE_SIZE:$_GET['page_size'];
  $pages = ceil($count/$page_size); //总共几页
  $page = ($page>$pages&&$pages!=0)?$pages:$page; //防止输入的当前页大于总页数
  
  $offset = ($page-1)*$page_size;
  
  $up_page = ($page-1)<1?1:($page-1); //上一页
  $next_page = ($page+1)>$pages?$pages:($page+1); //下一页
  //排序字段
  $fied_order = 'id';
  $type_order = empty($_GET['type_order'])?'desc':$_GET['type_order'];
  $type_order  = !in_array($type_order,array('desc','asc'))?'desc':$type_order;
  $sql = "select * from tb_admin where $where order by  $fied_order  $type_order  limit $offset ,$page_size";
  $list = $mysql->doSql($sql);
  

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>销售员列表页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a {
		    color: #fff;
		}
		.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
		  
		    vertical-align: middle;
		  
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>	
					
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				 <li><a href="javascript:void(0)">首页</a></li>
				 <li><a href="javascript:void(0)">销售员管理</a></li>
				 <li class="active">销售员列表</li>
				</ol>
				<form class="form-inline" method="get" action="admin_list.php">
				  <div class="form-group">
					 
				    <input type="text" class="form-control"placeholder="输入搜索关键字" name="keyword">
				  </div>
				 
				  <button type="submit" class="btn btn-success">查询</button>
				</form>
				<br>
				<table class="table table-hover">
					<tr>
						<td>ID</td>
						<td>员工编号</td>
						<td width="120">真实姓名</td>
						<td width="120">登录账号</td>
						<td>手机号码</td>
						<td>状态</td>
						<td width="90">添加时间</td>
						<td>操作</td>
					</tr>
					<?php if(empty($list)) echo "<tr><td colspan='13'>暂时信息</td></tr>"; ?>
					
					<?php foreach($list as $key=>$val){ ?>
					<tr>
						<td ><?php echo $val['id'] ?></td>
						<td><?php echo $val['admin_no'] ?></td>
						
						<td><?php echo $val['real_name'] ?></td>
						<td><?php echo $val['admin_name'] ?></td>
						<td><?php echo $val['phone'] ?></td>
						<td><?php echo empty($val['status'])?'<span class="label label-danger">失效</span>':'<span class="label label-success">有效</span>' ?></td>
					
						<td><?php echo $val['add_time'] ?></td>
						<td><a href="admin_edit.php?id=<?php echo $val['id'] ?>"  class="btn btn-warning btn-sm">修改</a><a href="admin_delete.php?id=<?php echo $val['id'] ?>"  class="btn btn-danger btn-sm" onclick="return confirm('确认要删除？')">删除</a></td>
						
					</tr>
					<?php } ?>
					
				</table>
				
				<nav aria-label="Page navigation">
				  <ul class="pagination">
					<li><a style="border: 0px;">共<?php echo $count ?>条记录；一共<?php echo $pages ?>页,当前是<?php echo $page ?>页</a></li> 
					 <li><a href="admin_list.php?page=1&keyword=<?php echo $keyword; ?>">首页</a></li> 
				    <li>
				      <a href="admin_list.php?page=<?php echo $up_page ?>&keyword=<?php echo $keyword; ?>" aria-label="Previous">
				        <span aria-hidden="true">&laquo;上一页</span>
				      </a>
				    </li>
				  
				    <li>
				      <a href="admin_list.php?page=<?php echo $next_page ?>&keyword=<?php echo $keyword; ?>" aria-label="Next">
				        <span aria-hidden="true">&raquo;下一页</span>
				      </a>
				    </li>
					 <li><a href="admin_list.php?page=<?php echo $pages ?>&keyword=<?php echo $keyword; ?>">尾页</a></li> 
				  </ul>
				</nav>
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->
			
			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
		</div>
		
		
		
		
	</body>
</html>
