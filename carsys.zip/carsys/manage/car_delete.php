
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>销售删除页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
		</style>
	</head>
	<body>
		
	</body>
</html>


<?php 
include_once('../config/init.php');
is_login_manage();//验证是否登录
$id = !empty($_GET['id'])?$_GET['id']:'0';

$admin = $mysql->where("id='$id'")->find("tb_admin");

if(empty($admin)){
	msgUrl('销售信息不存在',$url='admin_list.php');die();
}

$result =$mysql->where("id='$id'")->delete("tb_cars");
if($result){
	
	
        msgUrl('删除成功',$url='admin_list');die();
   }else{
      msgUrl('删除失败',$url='admin_list.php.php');die();
}

?>