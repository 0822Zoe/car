<?php
 include_once('../config/init.php'); //加载配置文件
is_login_manage();//验证是否登录
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>汽车列表页面</title>
		<!-- 引入bootsrap的css基础库 -->
		<link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<!-- 引入jquery库 -->
		<script src="bootstrap/js/jquery-3.4.1.min.js"></script>
		<!-- 引入bootsrap的js库 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<style type="text/css">
		.navbar-default {
		    background-color: #563d7c ; 
		    border-color: #563d7c;
		}
		.navbar-default .navbar-brand,.navbar-default .navbar-brand:hover {
		    color: #fff;
		}
		.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover {
		    color: #fff;
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<!-- 导航栏的开始 -->
			<div class="row">
			<?php include_once('nav.php'); ?>
			</div>
			<!-- 导航栏结束 -->
			<!-- 身体开始 -->
			<div class="row">
				<!-- 左侧导航开始 -->
				<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
					<?php include_once('left.php'); ?>
				
				</div>
				<!-- 左侧导航结束 -->
				<!-- 右侧内容开始 -->
				<div class="col-lg-10 col-md-9 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
				  <li><a href="javascript:void(0)">首页</a></li>
				  <li><a href="javascript:void(0)">汽车管理</a></li>
				  <li class="active">添加汽车</li>
				</ol>
				
				<form method="post" action="car_add.php" enctype="multipart/form-data">
				  <div class="form-group">
				    <label>汽车名称</label>
				    <input type="text" class="form-control" name="car_name">
				  </div>
				  <div class="form-group">
				    <label>汽车品牌</label>
				    <input type="text" class="form-control" name="car_brand">
				  </div>
				  <div class="form-group">
				    <label>汽车价格</label>
				    <input type="number" class="form-control" name="car_price">
				  </div>
				  <div class="form-group">
				    <label>库存</label>
				    <input type="number" class="form-control" name="sku">
				  </div>
				  <div class="form-group">
				    <label>销量</label>
				    <input type="number" class="form-control" name="sales">
				  </div>
				  <div class="form-group">
				    <label>浏览量</label>
				    <input type="number" class="form-control" name="hits">
				  </div>
				  <div class="form-group">
				    <label>汽车封面</label>
				    <input type="file" class="form-control" name="car_image" id="car_image" style="width: 250px;">
				<br>
				<img src="./bootstrap/images/default.jpg" style="height: 100px ;" id="show_image" class="img-thumbnail" />
				  </div>
				  <div class="form-group">
				    <label>汽车类型</label>
				  <select class="form-control" name="car_category">
					  <option value="0">选择汽车类型</option>
					  <option value="电动型">电动型</option>
					  <option value="混动型">混动型</option>
					  <option value="汽/柴油型">汽/柴油型</option>
				</select>
				  </div>
				  <div class="form-group">
				    <label>汽车简介</label>
				   <textarea class="form-control" rows="3" name="car_desc"></textarea>
				  </div>
				  <div class="form-group">
				    <label>推荐状态</label>
				  					<br>
				   <label class="radio-inline">
				     <input type="radio" name="is_recommend" id="is_recommend1" value="1"> 推荐
				   </label>
				   <label class="radio-inline">
				     <input type="radio" name="is_recommend" id="is_recommend2" value="0" checked="checked"> 不推荐
				   </label>
				  </div>
				  <div class="form-group">
				    <label>上架状态</label>
					<br>
				   <label class="radio-inline">
				     <input type="radio" name="status" id="status1" value="0"> 下架
				   </label>
				   <label class="radio-inline">
				     <input type="radio" name="status" id="status2" value="1" checked="checked"> 上架
				   </label>
				  </div>
				  <button class="btn btn-success" type="submit">发布</button>
				  <button class="btn btn-danger" type="reset">取消</button>
				</form>
				
				</div>
				<!-- 右侧内容结束 -->
			</div>
			<!-- 身体结束 -->

			<div class="row" style="margin-top:10px;">
						<?php include_once('../footer.php') ?>
			</div>
		</div>
	</body>
</html>
<script>
  const ipt = document.querySelector('#car_image')
  const img = document.querySelector('#show_image')
  ipt.addEventListener('change', (event) => {
  	// 获取当前图片信息
    let file = event.target.files[0]
    const reader = new FileReader()
    // 转化使用bese64格式
    reader.readAsDataURL(file)
    // 成功后的回调
    reader.onload = function () {
      img.setAttribute('src',this.result)
    }
  })
</script>

<?php 
//提交添加
  if(!empty($_POST)){
    $car_no = date("YmdHis").rand(1000,9999);
	$car_name = $_POST['car_name'];
    $car_price = $_POST['car_price'];
    $car_desc = $_POST['car_desc'];
    $sku = $_POST['sku'];
    $car_brand = $_POST['car_brand'];
    $car_category = $_POST['car_category'];
    $add_time = date("Y-m-d H:i:s",time());
    $sales = $_POST['sales'];
	$hits = $_POST['hits'];
	$status = $_POST['status'];
	$is_recommend = $_POST['is_recommend'];
	$car_image = '';
	//上传图片
	if(!empty($_FILES['car_image']['tmp_name'])){
		$car_image = uploadImage('car_image');
	}
	$insert_data =array(
	 'car_no'=>$car_no,
      'car_name' =>$car_name ,
      'car_price'=>$car_price,
      'car_desc'=>$car_desc,
      'car_brand'=>$car_brand,
	  'car_category'=>$car_category,
      'car_image'=>$car_image,
      'sales'=>$sales,
	  'hits'=>$hits,
	  'sku'=>$sku,
      'is_recommend'=>$is_recommend,
      'status'=>$status,
      'add_time'=>$add_time
  );
   $result = $mysql->insert('tb_cars',$insert_data);
   if($result){
		msgUrl('添加成功',$url='car_list.php');die();
   }else{
      msgUrl('添加失败',$url='car_add.php');die();
   }


  }

 ?>
