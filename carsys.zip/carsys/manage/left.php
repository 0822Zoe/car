<div class="list-group">
<a class="list-group-item active"  role="button" data-toggle="collapse" href="#collapseExample1" aria-expanded="false" aria-controls="collapseExample1">系统设置</a>
<div class="collapse in" id="collapseExample1">
	<a href="setting.php" class="list-group-item">设置</a>
</div>

<a class="list-group-item active"  role="button" data-toggle="collapse" href="#collapseExample2" aria-controls="collapseExample2">汽车管理</a>
<div class="collapse in" id="collapseExample2">
	<a href="car_add.php" class="list-group-item">添加汽车</a>
	<a href="car_list.php" class="list-group-item">汽车列表</a>
</div>


<a class="list-group-item active"  role="button" data-toggle="collapse" href="#collapseExample3" aria-expanded="false" aria-controls="collapseExample3">用户管理</a>
<div class="collapse in" id="collapseExample3">
	<a href="user_list.php" class="list-group-item">用户列表</a>
</div>

<a class="list-group-item active"  role="button" data-toggle="collapse" href="#collapseExample4" aria-expanded="false" aria-controls="collapseExample4">销售员管理</a>
<div class="collapse in" id="collapseExample4">
	<a href="admin_add.php" class="list-group-item">添加销售员</a>
	<a href="admin_list.php" class="list-group-item">销售员列表</a>
</div>

<a class="list-group-item active"  role="button" data-toggle="collapse" href="#collapseExample5" aria-expanded="false" aria-controls="collapseExample5">订单管理</a>
<div class="collapse in" id="collapseExample5">
	
	<a href="order_list.php" class="list-group-item">订单列表</a>
	<a href="analysis.php" class="list-group-item">业绩统计</a>
</div>

</div>
						
						