<?php
session_start();
//error_reporting(0);
header("Content-Type:text/html;charset=utf-8");//设置编码
define('__ROOT__',str_replace('\\','/',dirname(__FILE__).'/../'));
date_default_timezone_set('Asia/Shanghai');//设置时区
include_once(__ROOT__.'inc/mysql.class.php');//数据库操作类
include_once(__ROOT__.'config/config.php');//数据库配置文件
include_once(__ROOT__.'inc/sysfun.php');//系统函数库
include_once(__ROOT__.'inc/function.php');//逻辑函数库

$mysql = new MySQL($configArr);
$mysqli = mysqli_connect($configArr['host'],$configArr['user'],$configArr['passwd'],$configArr['dbname']);
mysqli_query($mysqli,"set names utf8");

