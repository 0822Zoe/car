<?php
//数据库配置
$configArr = array(
	  'host' =>'localhost',
      'port' => '3306',
	  'user' => 'root',
	  'passwd' => '',
	  'dbname' => 'db_carsys',
);
// 常用参数配置
define('PAGE_SIZE',20);//每页显示多少条信息